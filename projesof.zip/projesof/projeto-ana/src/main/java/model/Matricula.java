package model;

public class Matricula {
	private int  id;
	private int  ano;
	private int  semestre;
	private int  fkaluno;
	private int  fkdisciplina;
}
